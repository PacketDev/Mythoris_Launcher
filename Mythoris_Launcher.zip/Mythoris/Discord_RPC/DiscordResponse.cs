﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mythoris.Discord_RPC
{
    public enum DiscordResponse
    {
        No = 0,
        Yes = 1,
        Ignore = 2
    }
}