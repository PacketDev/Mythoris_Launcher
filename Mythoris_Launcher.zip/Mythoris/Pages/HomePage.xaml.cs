﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Net.Http;
using Newtonsoft.Json;
using System.Reflection;
using Mythoris.Discord_RPC;
using Mythoris.Services;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Markup;
using System.Threading;
using System.CodeDom.Compiler;
using Mythoris.Models;
using Mythoris.Constants;
using ICSharpCode.AvalonEdit.Document;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;

namespace Mythoris.Pages
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage
    {
        private readonly HttpClient _client;

        public HomePage()
        {
            _client = new HttpClient();

            InitializeComponent();
            InitializeJsonDocument();

            LaunchDataButton.Content = App.LocalizedStrings.Where(x => x.Key == "LaunchDataButtonText")?.FirstOrDefault().Value;

            App.ConfigService.LoadConfig();
        }

        private async void LaunchDataButton_Click(object sender, RoutedEventArgs e)
        {
            Process process = ProcessHelper.StartProcess("\\FortniteGame\\Binaries\\Win64\\FortniteLauncher.exe", true, "");
            Process process2 = ProcessHelper.StartProcess("\\FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping_BE.exe", true, "");
            Process process4 = ProcessHelper.StartProcess("\\FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping_EAC.exe", true, "");
            Process process3 = ProcessHelper.StartProcess("\\FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe", false, "-AUTH_TYPE=epic -AUTH_LOGIN=\"" + "\" -AUTH_PASSWORD=\"" + "\" SKIPPATCHCHECK");
            process3.WaitForInputIdle();
            ProcessHelper.InjectDll(process3.Id, System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Mythoris.dll"));
            Thread.Sleep(1000);
            process3.WaitForExit();
            process.Kill();
            process2.Kill();
        }

        private async void EmailDataButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var config = App.ConfigService.Config;

                var json = await SendAPIRequest<FortniteAPIResponse<Launch>>(FortniteAPI.Launch);
                var jsonString = JsonConvert.SerializeObject(json.Data, Formatting.Indented);

                // if (config.ExportJsonData && Directory.Exists(config.ExportPath))
                // File.WriteAllText(config.ExportPath + "\\FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe", jsonString);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Incorrect password or email.\n", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task<T> SendAPIRequest<T>(string url)
        {
            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();

            var data = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(data);
        }

        private async Task DownloadImage(string url, string path)
        {
            var response = await _client.GetAsync(url);
            using (var fileStream = File.Create(path))
                await response.Content.CopyToAsync(fileStream);
        }

        private void InitializeJsonDocument()
        {
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Mythoris.Resources.Files.JsonFormatting.xshd"))
            using (var reader = new System.Xml.XmlTextReader(stream))
            {
                var highlighting = HighlightingLoader.Load(reader, HighlightingManager.Instance);
            }
        }
    }
    }