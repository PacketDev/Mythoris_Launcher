﻿using System.Linq;
using System.Diagnostics;
using System.Windows.Input;

namespace Mythoris.Pages
{
    /// <summary>
    /// Interaction logic for ContactPage.xaml
    /// </summary>
    public partial class AboutPage
    {
        public AboutPage()
        {
            InitializeComponent();

            AboutTextBlock.Text = App.LocalizedStrings.Where(x => x.Key == "AboutTextBlock")?.FirstOrDefault().Value;
        }
    }
}
